package edu.cecyt9.ipn.intenciones_kahg;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button uno,dos,tres,cuatro,cinco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uno = findViewById(R.id.pagina);
        uno.setOnClickListener(this);
        dos = findViewById(R.id.llamada);
        dos.setOnClickListener(this);
        tres = findViewById(R.id.mapa);
        tres.setOnClickListener(this);
        cuatro = findViewById(R.id.foto);
        cuatro.setOnClickListener(this);
        cinco = findViewById(R.id.correo);
        cinco.setOnClickListener(this);
    }

    public void abrirPaginaWeb(View paginaWeb)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("http://cursosprogra.website"));
        startActivity(intent);
    }

    public void llamadaTelefono(View llamada)
    {
        Intent intent = new Intent(Intent.ACTION_DIAL,
                Uri.parse("tel:57296000"));
        startActivity(intent);
    }

    public void googleMaps(View maps)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("geo:19.453659, -99.175298"));
        startActivity(intent);
    }

    public void tomarFoto(View maps)
    {
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        startActivity(intent);
    }

    public void mandarCorreo(View correo)
    {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Asunto: Prueba");
        intent.putExtra(Intent.EXTRA_TEXT, "Contenido del correo: Prueba");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "eoropezag@ipn.mx"} );
        startActivity(intent);
    }

    @Override
    public void onClick(View view) {
        int seleccionado = view.getId();
        if(seleccionado == R.id.pagina){
            abrirPaginaWeb(view);
        }
        else{
            if(seleccionado == R.id.llamada){
                llamadaTelefono(view);
            }
            else{
                if(seleccionado == R.id.mapa){
                    googleMaps(view);
                }
                else{
                    if(seleccionado == R.id.foto){
                        tomarFoto(view);
                    }
                    else{
                        mandarCorreo(view);
                    }
                }
            }
        }
    }
}
